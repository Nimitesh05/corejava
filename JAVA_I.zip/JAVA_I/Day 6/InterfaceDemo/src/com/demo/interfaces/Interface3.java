package com.demo.interfaces;

public interface Interface3 extends Interface1,Interface2{

}
