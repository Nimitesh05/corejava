package com.demo.service;

public interface EmployeeSerivice {

	
	public void addEmp(int ch);
	
}
