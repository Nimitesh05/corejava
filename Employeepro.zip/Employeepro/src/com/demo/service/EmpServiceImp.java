package com.demo.service;

import java.util.*;

import com.demo.beans.ContractEmp;
import com.demo.beans.Employee;
import com.demo.beans.Person;
import com.demo.beans.SalariedEmp;
import com.demo.dao.EmpDaoImp;

//import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class EmpServiceImp implements EmployeeSerivice {
	
	static EmpDaoImp dobj;
	
	static
	{
		dobj=new EmpDaoImp();
	}
	@Override
	public void addEmp(int ch) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name");
		String name=sc.next();
		System.out.println("Enter date of joining");
		String date=sc.next();
		System.out.println("Enter Department");
		String dept=sc.next();
		System.out.println("Enter Designation");
		String desg=sc.next();
	
		Date d = null;
		SimpleDateFormat dt=new SimpleDateFormat("dd/mm/yyyy");
		try
		{
			d=dt.parse(date);
		}
		catch(ParseException e){
			
			e.printStackTrace();
			
		}
		
		Employee p;
		
		if( ch==1)
		{
			System.out.println("Enter Salary");
			double sal=sc.nextDouble();
			p=new SalariedEmp(name,d,dept,desg,sal);
	
		}
		else {
			
			System.out.println("Enter hours");
			int hrs=sc.nextInt();
			System.out.println("Enter Charges");
			double charges=sc.nextDouble();
			p=new ContractEmp(name,d,dept,desg,hrs,charges);
		}
		
		if( dobj.save(p))
		{
			System.out.println("Data Added Successfully");
		}
		else {
			System.out.println("Data not added");
		}
		
	}

}
