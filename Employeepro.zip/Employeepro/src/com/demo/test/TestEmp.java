package com.demo.test;

import java.util.Scanner;
import com.demo.service.*;

public class TestEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);

		EmpServiceImp obj=new EmpServiceImp();
		int choice=0;
		
		
		do
		{
			System.out.println("1.Add Employee \n2.Delete Employee \n3.Exit");
			System.out.println("Enter choice");
			choice=sc.nextInt();
			switch(choice)
			{
			
			
			case 1:
				System.out.println("Enter the type of Employee 1 or 2");
				int c=sc.nextInt();

				obj.addEmp(c);
				
				break;
				
				default :
					break;
			
			}
			
			
			
		}while(choice!=3);
		
	}

}
