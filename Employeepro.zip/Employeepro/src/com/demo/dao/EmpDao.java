package com.demo.dao;

import com.demo.beans.Person;

public interface EmpDao {
	
	
	public boolean save(Person ref);
	
}
