package com.demo.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.demo.beans.ContractEmp;
import com.demo.beans.Employee;
import com.demo.beans.Person;
import com.demo.beans.SalariedEmp;

public class EmpDaoImp {
	
	static List<Employee> list;
	
	static
	{
		list=new ArrayList<>();
		list.add(new SalariedEmp("Kavita",new Date(),"Hr","mgr",34252));
		list.add(new SalariedEmp("Rahul",new Date(),"Admin","Associate",23435));
		list.add(new ContractEmp("Ashu",new Date(),"Admin","mgr",23,34252));
		list.add(new ContractEmp("Pallavi",new Date(),"Admin","Associate",51,23435));
	}
	
	
	public boolean save(Employee ref)
	{
   
		list.add(ref);
		
		return true;
	}
	
	
	

}
